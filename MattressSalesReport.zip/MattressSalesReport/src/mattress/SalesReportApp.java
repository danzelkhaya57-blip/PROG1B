/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mattress;

/**
 *
 * @author Khaya Molekoa
 */

import java.util.Scanner;

/** Q1.1 - console sales report. */
public class SalesReportApp {

    public static void main(String[] args) {
        String[] products = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        int[][] sales = new int[products.length][3];
        Scanner in = new Scanner(System.in);

        for (int i = 0; i < products.length; i++) {
            for (int m = 0; m < 3; m++) {
                sales[i][m] = readInt(in, "Enter number of sales for month " + (m + 1)
                        + " for " + products[i] + " mattress: ");
            }
            System.out.println();
        }

        Product product = new Product(products, sales);
        new PrintProduct(product).printReport();
    }

    private static int readInt(Scanner in, String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = in.nextLine().trim();
            try {
                int value = Integer.parseInt(line);
                if (value >= 0) {
                    return value;
                }
            } catch (NumberFormatException ignored) { }
            System.out.println("Please enter a whole number of 0 or more.");
        }
    }
}

