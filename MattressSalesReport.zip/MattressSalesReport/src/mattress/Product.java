/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mattress;

/**
 *
 * @author Khaya Molekoa
 */

/** Q1.2 - holds product names (1D array) and monthly sales (2D array). */
public class Product implements IProduct {

    private final String[] names;   // 1D array: product names
    private final int[][] sales;    // 2D array: [product][month]

    public Product(String[] names, int[][] sales) {
        this.names = names;
        this.sales = sales;
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int[] productSales : sales) {
            for (int monthSales : productSales) {
                total += monthSales;
            }
        }
        return total;
    }

    /** Average over every product/month entry (153 / 9 = 17 in the sample). */
    @Override
    public double GetAverageProductSold() {
        int count = 0;
        for (int[] productSales : sales) {
            count += productSales.length;
        }
        return count == 0 ? 0 : (double) GetTotalProductsSold() / count;
    }

    /** Product with the highest total sales, e.g. "Cozy Nights Monarch(63)". */
    @Override
    public String GetMostPopularProduct() {
        int bestIndex = 0;
        int bestTotal = -1;
        for (int i = 0; i < sales.length; i++) {
            int productTotal = 0;
            for (int monthSales : sales[i]) {
                productTotal += monthSales;
            }
            if (productTotal > bestTotal) {
                bestTotal = productTotal;
                bestIndex = i;
            }
        }
        return names[bestIndex] + "(" + bestTotal + ")";
    }
}

