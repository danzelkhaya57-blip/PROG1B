/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.consolesales;

/**
 *
 * @author Khaya Molekoa
 */

public interface Consoles {

    String getConsoleType();

    String getStore();

    int getTotalSales();
}

