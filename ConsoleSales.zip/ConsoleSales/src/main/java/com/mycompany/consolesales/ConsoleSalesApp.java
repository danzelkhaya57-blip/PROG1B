/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consolesales;

/**
 *
 * @author Khaya Molekoa
 */

import java.util.Scanner;

public class ConsoleSalesApp {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // Display console options
        System.out.println("SELECT CONSOLE TYPE");
        System.out.println("1) PS5");
        System.out.println("2) XBOX");
        System.out.println("3) Switch");

        System.out.print("Enter your choice: ");
        int choice = input.nextInt();

        input.nextLine();

        // Variable for console type
        String consoleType = "";

        // Select console type
        if (choice == 1) {
            consoleType = "PS5";
        } else if (choice == 2) {
            consoleType = "XBOX";
        } else if (choice == 3) {
            consoleType = "Switch";
        } else {
            System.out.println("Invalid console choice.");
            input.close();
            return;
        }

        // Enter store name
        System.out.print("Enter the store: ");
        String store = input.nextLine();

        // Enter total sales
        System.out.print(
            "Enter the total sales of "
            + consoleType
            + " consoles for the "
            + store
            + " : "
        );

        int totalSales = input.nextInt();

        // Create ConsoleSales object
        ConsoleSales sales = new ConsoleSales(
            consoleType,
            store,
            totalSales
        );

        // Display report
        System.out.println();
        System.out.println("CONSOLE SALES REPORT");
        System.out.println("--------------------");

        System.out.println(
            "Console type: " + sales.getConsoleType()
        );

        System.out.println(
            "Store: " + sales.getStore()
        );

        System.out.println(
            "Total sales: " + sales.getTotalSales()
        );

        input.close();
    }
}
