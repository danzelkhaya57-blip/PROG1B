/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.eletronicssales;

/**
 *
 * @author Khaya Molekoa
 */
public class EletronicsSales {

    public static void main(String[] args) {

        // Single-dimensional array for the cities
        String[] cities = {
            "Cape Town",
            "Port Elizabeth",
                             "Pretoria"
        };

        // Single-dimensional array for the gaming consoles
        String[] consoles = {
            "PS5",
            "XBOX",
            "Nintendo Switch"
        };

        // Two-dimensional array for sales
        // Rows = cities
        // Columns = consoles
        int[][] sales = {
            {1000, 2000, 3000}, // Cape Town
            {2000, 3000, 4000}, // Port Elizabeth
            {1500, 1100, 1200}  // Pretoria
        };

        // Display the heading
        System.out.println("NUMBER 1 ELECTRONICS FRANCHISE");
        System.out.println("YEARLY GAMING CONSOLE SALES");
        System.out.println("----------------------------------------");

        // Variable to store the total sales for all cities
        int totalSales = 0;

        // Variables to find the city with the most sales
        int highestSales = 0;
        String cityWithMostSales = "";

        // Display sales for each city
        for (int i = 0; i < cities.length; i++) {

            // Store the total sales for the current city
            int cityTotal = 0;

            System.out.println("\nCity: " + cities[i]);

            // Loop through the consoles
            for (int j = 0; j < consoles.length; j++) {

                System.out.println(consoles[j] + ": " + sales[i][j]);

                // Add the console sales to the city total
                cityTotal = cityTotal + sales[i][j];
            }

            // Display total sales for the city
            System.out.println("Total sales: " + cityTotal);

            // Add city total to the overall total
            totalSales = totalSales + cityTotal;

            // Check if this city has the highest sales
            if (cityTotal > highestSales) {
                highestSales = cityTotal;
                cityWithMostSales = cities[i];
            }
        }

        // Display the overall total
        System.out.println("\n----------------------------------------");
        System.out.println("TOTAL SALES FOR ALL CITIES: " + totalSales);

        // Display city with the most sales
        System.out.println("CITY WITH THE MOST SALES: " + cityWithMostSales);
        System.out.println("HIGHEST SALES: " + highestSales);
    }
}
