/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mattress;

/**
 *
 * @author Khaya MOlekoa
 */

/** Q2.5 - VAT 15%, Commission 5%, Total = price + VAT + commission. */
public class ProductCalculations implements IProductCalculations {

    private final double price;

    public ProductCalculations(double price) {
        this.price = price;
    }

    @Override
    public double GetVat() {
        return price * 15 / 100;
    }

    @Override
    public double GetCommission() {
        return price * 5 / 100;
    }

    @Override
    public double GetTotal() {
        return price + GetVat() + GetCommission();
    }
}

